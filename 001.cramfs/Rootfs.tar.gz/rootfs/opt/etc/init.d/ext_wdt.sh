#!/bin/sh

echo "external watchodg init..."

/bin/ext_wdt_test &
